from threading import *


class Sensor_Fusion(Thread):
    def __init__(self):

        super(Sensor_Fusion, self).__init__()